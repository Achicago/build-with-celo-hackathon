import abi from "./Transactions.json";

// export const contractAddress = "0xfCCF80344a668b72ac4Be23513F0E9E4a35C84fA";
export const contractAddress = "0x30C06ac9FCAfD569e62bc40e5EB39a32495BbE5C";

export const contractABI = abi.abi;